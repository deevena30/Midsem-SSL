#! /bin/bash

# For Testing
INSTRUCTOR_SCRIPTS="/home/.evaluationScripts"
LAB_DIRECTORY="/home/labDirectory"


ptcd=$(pwd)

cd $INSTRUCTOR_SCRIPTS

cp -r $LAB_DIRECTORY/submission.sh .autograder/

cd ./.autograder/

chmod -R 777 submission.sh

python3 script.py

# rm -r $list_of_files

cd "$ptcd"
