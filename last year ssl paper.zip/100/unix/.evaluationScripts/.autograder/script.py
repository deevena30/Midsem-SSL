import os
import json

overall = {"data": []
}

data = []

test_case_num = 5
submission_file_name = 'submission.sh'

command = 'clear'
os.system(command)
#------------------------------test cases---------------------------

for i in range(1,test_case_num+1):
    
    os.system("rm -f expected_michaelsleep.txt michaelsleep.txt expected_michaelhero.txt michaelhero.txt")
    
    msg = ""
    total = 0
    result = {
        "testid": "1",
        "status": "success",
        "score": 0,
        "maximum marks" : 2,
        "message": ""
        }
    # os.system(f"cp ../../labDirectory/submission.sh .")
    os.system(f"cp ./testcases/{i}/* .")
    # os.system(f"cp ./testcases/{i}/{analysis.txt,expected_michaelsleep.txt,expected_michaelhero.txt} .")
    os.system("ls")
    # os.system("ls")
    
    command=f"bash {submission_file_name}"
    rval = os.system(command)
  
    if rval == 0 :
        msg = msg + str("Script Executed Successfully. ")
    else :
        msg = msg + str("Error in Executing Script. ")
        result["status"]="failed"
        continue
    
    command="diff -Bw michaelsleep.txt expected_michaelsleep.txt"
    rval = os.system(command)
    
    if rval == 0:
        total=total+1
        msg = msg + str("michaelsleep.txt is correct. ")
    else:
        msg = msg + str("michaelsleep.txt is not as Expected. Check testcase ")
        msg = msg + str(i) +"/ . "

    command="diff -Bw michaelhero.txt expected_michaelhero.txt"
    rval = os.system(command)
    
    if rval == 0:
        total=total+1
        msg = msg + str("michaelhero.txt is correct. ")
    else:
        msg = msg + str("michaelhero.txt is not as Expected. Check testcase ")
        msg = msg + str(i) +"/ ."

    result["testid"] = i
    result["score"] = total
    result["message"] = msg
    data.append(result)

os.system("rm -f expected_michaelsleep.txt michaelsleep.txt expected_michaelhero.txt michaelhero.txt")
# os.system("rm -rf output.txt correct_output.txt")

overall['data'] = data
print(json.dumps(overall, indent=4))
with open('../evaluate.json', 'w') as f:
	json.dump(overall,f,indent=4)