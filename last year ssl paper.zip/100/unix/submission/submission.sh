# Write your code in this file. All the best!
# Write your code in this file. All the best!
echo Name,LoanID,PaymentHistory,CreditUtilization,LengthOfCreditHistory>michaelsleep.txt

grep -E "^[A-Z]{1}[a-z]{1,},[A-Z][A-Z]@[0-9][0-9][1-9],[0-9]*,[0-9]*,[0-9]+days|[A-Z][a-z]+,[A-Z][A-Z]@[0-9][1-9]0,[0-9]*,[0-9]*,[0-9]+days|[A-Z][a-z]+,[A-Z][A-Z]@[1-9][0-9]0,[0-9]*,[0-9]*,[0-9]+days$" analysis.txt >>michaelsleep.txt

echo "Name LoanID" >michaelhero.txt
grep -E "^[A-Z]{1}[a-z]{1,},[A-Z][A-Z]@[0-9][0-9][1-9],[0-9]*,[0-9]*,[0-9]+days|[A-Z][a-z]+,[A-Z][A-Z]@[0-9][1-9]0,[0-9]*,[0-9]*,[0-9]+days|[A-Z][a-z]+,[A-Z][A-Z]@[1-9][0-9]0,[0-9]*,[0-9]*,[0-9]+days$" analysis.txt|cut  -d "," -f 1,2 --output-delimiter=" "<202c>|sort -t ' ' -k1 >>michaelhero.txt
