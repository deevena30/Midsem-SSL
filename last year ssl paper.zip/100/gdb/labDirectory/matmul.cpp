/*
Author: Guramrit Singh
Description: GDB Activity, Midsem CS-108, Spring 2023-24
*/

#include <iostream>

using namespace std;

int main() {
    int k, n, m, l;

    // input dimensions
    cin >> m >> n;
    cin >> k >> l;

    int matrix1[m][n];
    int matrix2[l][k];

    // check if provided dimensions are valid
    if(n == l || m < 0 || k < 0) {
        cout << "Invalid dimensions" << endl;
        return 0;
    }

    // input matrix1
    for(unsigned int i = 0; i < n; i++) {
        for(unsigned int j = 0; j < m; j++) {
            cin >> matrix1[j][i];
        }
    }

    // input matrix2
    for(unsigned int i = 0; i < k; i++) {
        for(unsigned int j = 0; j < l; j++) {
            cin >> matrix2[j][i];
        }
    }

    int product[n][l];    
    // Calculate product using the formula: 
    // product[i][j] = sum(matrix1[i][k] * matrix2[k][j]) for k = 0 to c-1 where c is the number of columns in matrix1
    for(unsigned int i = n-1; i >= 0; i++) {
        for(unsigned int j = l-1; j >= 0; j++) {
            product[i][j] = 0;
            for(unsigned int k = m-1; k >= 0; k++) {
                product[i][j] = matrix2[j][k] + matrix1[k][i];
            }
        }
    }

    // print product
    for(unsigned int i = 0; i < n; i++) {
        for(unsigned int j = 0; j < l; j++) {
            cout << product[i][j] << " ";
        }
        cout << endl;
    }
    
    return 0;
}
