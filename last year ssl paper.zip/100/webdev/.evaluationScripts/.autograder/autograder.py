from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import os
import time
import json

overall = {"data": []}

data = []

testcases = [
    {
        "Input": "2",
        "Alert": "Thank you for your response!"
    },
    {
        "Input": "7",
        "Alert": "Thank you for your response!"
    },
    {
        "Input": "-1",
        "Alert": "Invalid Response. Try again, please!"
    },
    {
        "Input": "",
        "Alert": "Invalid Response. Try again, please!"
    },
    {
        "Input": "11",
        "Alert": "Invalid Response. Try again, please!"
    },
]

#-----------------------------------------------Starting Chromedriver---------------------------------------------------
chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable-dev-shm-usage')
chrome_service = Service('/usr/bin/chromedriver')
driver = webdriver.Chrome(service=chrome_service, options=chrome_options)
driver2 = webdriver.Chrome(service=chrome_service, options=chrome_options)
current_directory = os.getcwd()
file_url = 'file://' + os.path.join(current_directory, 'survey.html')
file_url2 = 'file://' + os.path.join(current_directory, 'javascript.html')
driver.get(file_url)
driver2.get(file_url2)
time.sleep(2)
#----------------------------------------------------------------------------------------------------------------------

#----------------------------------------------------------------------------------------------------------------------
def grade_against_testcases():
    message = ""
    input_ele = None
    try:
        input_ele = driver2.find_element(By.XPATH, '//div//input[@id="rating_input"]')
    except Exception:
        message = "There should have been an <input> tag with id 'rating_input'. "
    button = None
    try:
        button = driver2.find_element(By.XPATH, '//button[text()="Check Rating"]')
    except Exception:
        message += "There should have been a <button> tag named 'Check Rating'. "
    if input_ele == None or button == None:
        for i in range(len(testcases)):
            data.append({
                "testid": f'Testcase {i+1}',
                "status": "failed",
                "score": 0,
                "maximum marks" : 1,
                "message": message
            })
        return
    for i in range(len(testcases)):
        input_ele = driver2.find_element(By.XPATH, '//div//input[@id="rating_input"]')
        button = driver2.find_element(By.XPATH, '//button[text()="Check Rating"]')
        input_ele.clear()
        input_ele.send_keys(testcases[i]['Input'])
        button.click()
        alert = None
        try:
            alert = WebDriverWait(driver2, 2).until(EC.alert_is_present())
        except:
            data.append({
                "testid": f'Testcase {i+1}',
                "status": "failed",
                "score": 0,
                "maximum marks" : 1,
                "message": "No alert came for this testcase."
            })
            driver2.refresh()
            continue
        if alert.text == testcases[i]['Alert']:
            data.append({
                "testid": f'Testcase {i+1}',
                "status": "success",
                "score": 1,
                "maximum marks" : 1,
                "message": "Testcase passed."
            })
        else:
            data.append({
                "testid": f'Testcase {i+1}',
                "status": "failed",
                "score": 0,
                "maximum marks" : 1,
                "message": "Alert came. But alert message isn't as expected."
            })
        alert.accept()
        driver2.refresh()
#----------------------------------------------------------------------------------------------------------------------

def run_autograder():
    #--------------------------------------------------Checking Title--------------------------------------------------
    if driver.title == 'CSE Trip Survey':
        data.append({
            "testid": "Title",
            "status": "success",
            "score": 0.25,
            "maximum marks" : 0.25,
            "message": "Page title is correct."
        })
    else:
        data.append({
            "testid": "Title",
            "status": "failed",
            "score": 0,
            "maximum marks" : 0.25,
            "message": "Error: Page title is wrong or not set."
        })
    #------------------------------------------------------------------------------------------------------------------
    
    #-------------------------------------------------Checking Heading-------------------------------------------------
    try:
        h1_element = driver.find_element(By.TAG_NAME, 'h1')
        h1_text = h1_element.text
        if h1_text == 'CSE Trip Anonymous Feedback':
            data.append({
                "testid": "Heading",
                "status": "success",
                "score": 0.25,
                "maximum marks" : 0.25,
                "message": "<h1> heading is correct."
            })
        else:
            data.append({
                "testid": "Heading",
                "status": "failed",
                "score": 0,
                "maximum marks" : 0.25,
                "message": "Error: <h1> heading is wrong."
            })
    except NoSuchElementException:
        data.append({
            "testid": "Heading",
            "status": "failed",
            "score": 0,
            "maximum marks" : 0.25,
            "message": "Error: No <h1> tag found."
        })
    #------------------------------------------------------------------------------------------------------------------

    #----------------------------------------------------Checking Q1---------------------------------------------------
    total = 0
    message = ""
    result={
        "testid": "Q1 <div>",
        "status": "success",
        "score": 0,
        "maximum marks" : 1,
        "message": ""
    }
    form_container = None
    try:
        form_container = driver.find_element(By.XPATH, '//div[@id="formContainer"]')
    except Exception:
        message = message + "Error: The id='formContainer' <div> should have been present. "
        result['status'] = 'failed'
    if form_container != None:
        Q1 = None
        try:
            Q1 = driver.find_element(By.XPATH, '//div[@id="formContainer"]//div[@id="Q1" and @class="Box"]')
        except Exception:
            message = message + "Error: The <div> container of class 'Box' and id 'Q1' should have been present. "
            result['status'] = 'failed'
        if Q1 != None:
            Q1_p = None
            try:
                Q1_p = driver.find_element(By.XPATH, '//div[@id="formContainer"]//div[@id="Q1" and @class="Box"]//p')
            except Exception:
                message = message + "Error: There should be a <p> tag in <div> id 'Q1'. "
                result['status'] = 'failed'
            if Q1_p != None:
                if Q1_p.text == "Q1: How would you rate the trip?":
                    total += 0.5
                else:
                    message = message + "Error: The text in <p> tag for Q1 is incorrect. "
                    result['status'] = 'failed'
            Q1_input = None
            try:
                Q1_input = driver.find_element(By.XPATH, '//div[@id="formContainer"]//div[@id="Q1" and @class="Box"]//input[@type="text" and @class="Rating"]')
            except Exception:
                message = message + "Error: There should be a <input> tag of type 'text' and class 'Rating' in <div> id 'Q1'. "
                result['status'] = 'failed'
            if Q1_input != None:
                total += 0.5
    
    result['score'] = total
    if total == 1:
        result['score'] = 1
    if message == "":
        message = "<div> correctly built for Q1."
    result['message'] = message
    data.append(result)
    #------------------------------------------------------------------------------------------------------------------

    #----------------------------------------------------Checking Q2---------------------------------------------------
    total = 0
    message = ""
    result={
        "testid": "Q2 <div>",
        "status": "success",
        "score": 0,
        "maximum marks" : 1,
        "message": ""
    }
    form_container = None
    try:
        form_container = driver.find_element(By.XPATH, '//div[@id="formContainer"]')
    except Exception:
        message = message + "Error: The id='formContainer' <div> should have been present. "
        result['status'] = 'failed'
    if form_container != None:
        Q2 = None
        try:
            Q2 = driver.find_element(By.XPATH, '//div[@id="formContainer"]//div[@id="Q2" and @class="Box"]')
        except Exception:
            message = message + "Error: The <div> container of class 'Box' and id 'Q2' should have been present. "
            result['status'] = 'failed'
        if Q2 != None:
            Q2_p = None
            try:
                Q2_p = driver.find_element(By.XPATH, '//div[@id="formContainer"]//div[@id="Q2" and @class="Box"]//p')
            except Exception:
                message = message + "Error: There should be a <p> tag in <div> id 'Q2'. "
                result['status'] = 'failed'
            if Q2_p != None:
                if Q2_p.text == "Q2: How would you rate the fun you had?":
                    total += 0.5
                else:
                    message = message + "Error: The text in <p> tag for Q2 is incorrect. "
                    result['status'] = 'failed'
            Q2_input = None
            try:
                Q2_input = driver.find_element(By.XPATH, '//div[@id="formContainer"]//div[@id="Q2" and @class="Box"]//input[@type="text" and @class="Rating"]')
            except Exception:
                message = message + "Error: There should be a <input> tag of type 'text' and class 'Rating' in <div> id 'Q2'. "
                result['status'] = 'failed'
            if Q2_input != None:
                total += 0.5
    
    result['score'] = total
    if total == 1:
        result['score'] = 1
    if message == "":
        message = "<div> correctly built for Q2."
    result['message'] = message
    data.append(result)
    #------------------------------------------------------------------------------------------------------------------

    #-------------------------------------------------Inline CSS check-------------------------------------------------
    result={
        "testid": "Inline CSS",
        "status": "success",
        "score": 0,
        "maximum marks" : 0.5,
        "message": ""
    }
    message = ""
    total = 0
    h1_element = None
    try:
        h1_element = driver.find_element(By.TAG_NAME, 'h1')
    except Exception:
        message = message + "There should be a <h1> tag element to apply inline CSS on. "
        result['status'] = 'failed'
    if h1_element != None:
        style_attribute_value = None
        try:
            style_attribute_value = h1_element.get_attribute('style')
        except Exception:
            message = message + "Error: Use correct attribute for inline CSS. "
            result['status'] = 'failed'
        if style_attribute_value != None:
            if 'text-align' in style_attribute_value and 'center' in style_attribute_value:
                message = message + "Inline CSS done correctly. "
                total = 0.5
            else:
                message = message + "Error: Inline CSS is done incorrectly. "
                result['status'] = 'failed'
    
    result['score'] = total
    result['message'] = message
    data.append(result)
    #------------------------------------------------------------------------------------------------------------------
    
    #------------------------------------------------Internal CSS check------------------------------------------------
    result={
        "testid": "Internal CSS",
        "status": "success",
        "score": 0,
        "maximum marks" : 1,
        "message": ""
    }
    message = ""
    total = 0
    form_container = None
    try:
        form_container = driver.find_element(By.ID, 'formContainer')
    except Exception:
        message = message + "Error: The id='formContainer' <div> should have been present. "
        result['status'] = 'failed'
    if form_container != None:
        background_color = form_container.value_of_css_property('background-color')
        style_tag = None
        try:
            style_tag = driver.find_element(By.TAG_NAME, 'style')
            total += 0.5
        except Exception:
            message = message + "Error: You need to use correct tag for Internal CSS. "
            result['status'] = 'failed'
        if style_tag != None:
            style_content = style_tag.get_attribute('textContent')
            if (background_color.lower() == 'rgba(255, 182, 193, 1)' or background_color.lower() == 'lightpink') and '#formContainer' in style_content and ('background-color' in style_content or 'background' in style_content) and 'lightpink' in style_content:
                message = message + "Internal CSS done correctly. "
                total += 0.5
            else:
                message = message + "Error: <style> tag found but Internal CSS is done incorrectly. "
                result['status'] = 'failed'

    result['score'] = total
    if total == 1:
        result['score'] = 1
    result['message'] = message
    data.append(result)
    #------------------------------------------------------------------------------------------------------------------
    
    #------------------------------------------------External CSS check------------------------------------------------
    # Retrieve the content of the external CSS file
    css_content = None
    with open("./style.css", 'r') as css_file:
        css_content = css_file.read()
    if css_content and ('.Rating' in css_content or 'input' in css_content) and 'width' in css_content and '50px' in css_content:
        data.append({
            "testid": "External CSS",
            "status": "success",
            "score": 1,
            "maximum marks" : 1,
            "message": "External CSS done correctly."
        })
    else:
        data.append({
            "testid": "External CSS",
            "status": "failed",
            "score": 0,
            "maximum marks" : 1,
            "message": "External CSS is incorrect."
        })
    #------------------------------------------------------------------------------------------------------------------
    
    grade_against_testcases()

if __name__ == "__main__":

    rval = os.system('ls survey.html style.css javascript.html script.js > /dev/null 2> /dev/null')

    if rval != 0:
        data.append({
            "testid": "Files",
            "status": "failed",
            "score": 0,
            "maximum marks" : 10,
            "message": "Files not found. Further checking stopped."
        })
    else:
        data.append({
            "testid": "Files",
            "status": "success",
            "score": 0,
            "maximum marks" : 0,
            "message": "All files are present!"
        })
        run_autograder()

    os.system('touch ../evaluate.json')
    os.system("clear")
    overall['data'] = data
    print(json.dumps(overall, indent=4))
    with open('../evaluate.json', 'w') as f:
        json.dump(overall,f,indent=4)
