function checkRating()
{
    //TODO: Complete this fucntion as stated in the problem statement
    //This function doesn't take any parameters nor return any value.
    
}