function checkRating()
{
    //TODO: Complete this fucntion as stated in the problem statement
    //This function doesn't take any parameters nor return any value.
    if(document.getElementById("rating_input").value=""||document.getElementById("rating_input").value<0||document.getElementById("rating_input").value>10)
    alert("Invalid Response. Try again, please!");
    else alert("Thank you for your response!");
}