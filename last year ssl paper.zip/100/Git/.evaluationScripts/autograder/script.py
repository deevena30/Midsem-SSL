# pip install GitPython

import git
import json
import os
import tarfile

overall = {"data":[
		{
			"testid": "1",
			"status": "failure",
			"score": 0,
			"maximum marks" : 40,
			"message": ""
		}
	]
}

with open('../evaluate.json', 'w') as f:
	json.dump(overall,f,indent=4)

overall["data"][0]["status"] = "success"

os.system("rm -rf ./working_directory/ &> /dev/null")
my_tar = tarfile.open('./working_directory.tar.gz')
my_tar.extractall("./")
my_tar.close()
os.system('clear')

try:
	repo = git.Repo("./working_directory/")
except:
	overall['data'][0]["score"] = 0
	overall['data'][0]["message"] = "Could not find 'git' project folder"
	overall['data'][0]["status"] = "failure"
	print(json.dumps(overall, indent=4))

	with open('../evaluate.json', 'w') as f:
		json.dump(overall,f,indent=4)
	os.system("rm -rf ./working_directory/")      
	exit()

result = 0

try:	
	msg=""	
	branches = [head.name for head in repo.heads]
	checkThirdBranch = False
	checkSecondBranch = False
	checkFirstBranch = False
	checkMaster = False
	checkFirstMerge = True
	checkSecondMerge = True
	expected_branches = ["master", "first-branch", "second-branch", "third-branch"]
 
	for branch in branches:
		if branch not in expected_branches:
			overall['data'][0]["score"] = 0
			overall['data'][0]["message"] = "Extra branch found. Evaluation failed. "
			overall['data'][0]["status"] = "failure"
			print(json.dumps(overall, indent=4))

			with open('../evaluate.json', 'w') as f:
				json.dump(overall,f,indent=4)
			exit()
		elif branch=="third-branch":
			checkThirdBranch = True
			commit_third_branch=list(repo.iter_commits("third-branch"))
		elif branch=="second-branch":
			checkSecondBranch = True
			commit_second_branch=list(repo.iter_commits("second-branch"))
		elif branch=="first-branch":
			checkFirstBranch = True
			commit_first_branch=list(repo.iter_commits("first-branch"))
		elif branch=="master":
			checkMaster = True
			commit_master=list(repo.iter_commits("master"))

	if not checkMaster:
		msg+="Master branch not found. "
		checkFirstMerge = False
		checkSecondMerge = False
	if not checkFirstBranch:
		msg+="First-branch not found. "
		checkFirstMerge = False
		checkSecondMerge = False
	if not checkSecondBranch:
		msg+="Second-branch not found. "
		checkSecondMerge = False
	if not checkThirdBranch:	
		msg+="Third-branch not found. "

	if checkMaster and len(commit_master)!=10:
		msg+="Master branch has incorrect number of commits for second merge. "
		checkSecondMerge = False
		if len(commit_master)!=7:
			msg+="Master branch has incorrect number of commits for first merge. "
			checkFirstMerge = False
			checkMaster = False
	if checkFirstBranch and len(commit_first_branch)!=5:
		msg+="First-branch has incorrect number of commits. "
		checkFirstMerge = False
		checkSecondMerge = False
		checkFirstBranch = False
	if checkSecondBranch and len(commit_second_branch)!=5:
		msg+="Second-branch has incorrect number of commits. "
		checkSecondMerge = False
		checkSecondBranch = False
	if checkThirdBranch and len(commit_third_branch)!=3:
		msg+="Third-branch was not created at the correct commit or has more than 1 commit or no commit after branching from master."
		checkThirdBranch = False

	if not checkThirdBranch:
		msg+="Not evaluating recovery of file5.cpp. "
	if not checkFirstMerge:
		msg+="Not evaluating first merge. "
	if not checkSecondBranch:
		msg+="Not evaluating extra.cpp removal. "
	if not checkSecondMerge:
		msg+="Not evaluating second merge. "
	
	second_merge_commit_hashes = ["64dc5e7a6663783dcb8916e3246418ed1672e19c", "dcef025598ce39d7764f9cf0e06c0531e00ab953", "06f87aa37732d14bd4648e92cd4bd36aa96750ef", "71eea1a417247c67f8f3792f8fa66ceaa4278f05", "cb5604a639117a019d8612a46c15408a26d5cfa7", "18cf3ffc8d205c49bacb89287519ea14ea7557e0", "f23e22d72f5b7184ec151180dd9cd8c134c0014f"]

	first_merge_commit_hashes = ["64dc5e7a6663783dcb8916e3246418ed1672e19c", "dcef025598ce39d7764f9cf0e06c0531e00ab953", "06f87aa37732d14bd4648e92cd4bd36aa96750ef", "cb5604a639117a019d8612a46c15408a26d5cfa7", "18cf3ffc8d205c49bacb89287519ea14ea7557e0", "f23e22d72f5b7184ec151180dd9cd8c134c0014f"]

	first_commit_hashes = ["dcef025598ce39d7764f9cf0e06c0531e00ab953", "06f87aa37732d14bd4648e92cd4bd36aa96750ef", "cb5604a639117a019d8612a46c15408a26d5cfa7", "18cf3ffc8d205c49bacb89287519ea14ea7557e0", "f23e22d72f5b7184ec151180dd9cd8c134c0014f"]

	second_commit_hashes = ["71eea1a417247c67f8f3792f8fa66ceaa4278f05", "cb5604a639117a019d8612a46c15408a26d5cfa7", "18cf3ffc8d205c49bacb89287519ea14ea7557e0", "f23e22d72f5b7184ec151180dd9cd8c134c0014f"]
						 
	third_commit_hashes = ["18cf3ffc8d205c49bacb89287519ea14ea7557e0", "f23e22d72f5b7184ec151180dd9cd8c134c0014f"]

	author_name = "student-cs108"
	author_email = "student@cs108.cse.iitb.ac.in"
	author_marks = 0
	
	if checkMaster:
		if checkSecondMerge:
			for i in range(7):
				if commit_master[i+3].hexsha!=second_merge_commit_hashes[i]:
					msg += "Original repository modified. Master branch has been modified. Not evaluating merge commits. "
					checkFirstMerge = False
					checkSecondMerge = False
					checkMaster = False
					break
		elif checkFirstMerge:
			for i in range(6):	
				if commit_master[i+1].hexsha!=first_merge_commit_hashes[i]:
					msg += "Original repository modified. Master branch has been modified. Not evaluating merge commits. "
					checkFirstMerge = False
					checkMaster = False
					break
		if checkMaster:
			if checkSecondMerge:
				for i in range(3):
					if commit_master[i].author.name==author_name and commit_master[i].author.email==author_email:
						author_marks+=1
			elif checkFirstMerge:
				if commit_master[0].author.name==author_name and commit_master[0].author.email==author_email:
					author_marks+=1
			
	if checkFirstBranch:
		for i in range(5):
			if commit_first_branch[i].hexsha!=first_commit_hashes[i]:
				msg+="Original repository modified. First-branch has been modified. Not evaluating merge commits. "
				checkFirstMerge = False
				checkSecondMerge = False
				checkFirstBranch = False
				break

	if checkSecondBranch:
		for i in range(4):
			if commit_second_branch[i+1].hexsha!=second_commit_hashes[i]:
				msg+="Original repository modified. Second-branch has been modified. Not evaluating extra.cpp removal and merge commits. "
				checkSecondMerge = False
				checkSecondBranch = False
				break
		if checkSecondBranch:
			if commit_second_branch[0].author.name==author_name and commit_second_branch[0].author.email==author_email:
				author_marks+=1

	if checkThirdBranch:
		for i in range(2):
			if commit_third_branch[i+1].hexsha!=third_commit_hashes[i]:
				msg+="Original repository modified. Third-branch has been modified. Not evaluating recovery of file5.cpp. "
				checkThirdBranch = False
				break
		if checkThirdBranch:
			if commit_third_branch[0].author.name==author_name and commit_third_branch[0].author.email==author_email:
				author_marks+=1

	msg+=f"Author name and email marks: {author_marks}. "	
	result+=author_marks
	
	if checkThirdBranch:
		blobs = {}
		check = True
		for blob in commit_third_branch[0].tree.blobs:
			blobs[blob.name] = blob
		if len(blobs)!=1 or "file5.cpp" not in blobs.keys() or len(commit_third_branch[0].tree.trees)!=0:
			msg+="Third-branch has incorrect files and/or directories. "
		else:
			if commit_third_branch[0].message.strip("\n").strip(" ").lower() == "recovered file5.cpp":
				msg+="Third-branch commit message is correct. "
				result+=2
			else:
				msg+="Third-branch commit message is incorrect. "
			curr_blob=blobs["file5.cpp"]
			curr_blob.stream_data(open("file.cpp","wb"))
			ret = os.system("g++ file.cpp")
			if ret!=0:
				msg+="file5.cpp has compilation error in third-branch. "
			else:
				for i in range(3):
					os.system("timeout 2s ./a.out < testcases/m3_5/in_"+str(i+1)+".txt > output.txt")
					ret = os.system("diff -Bw output.txt testcases/m3_5/out_"+str(i+1)+".txt")
					if ret!=0:
						msg+="file5.cpp failed testcases. "
						check = False
						break
				if check:
					msg+="Third-branch has correct file5.cpp. "
					result+=8

	if checkSecondBranch:		
		blobs = {}
		check = True
		for blob in commit_second_branch[0].tree.blobs:
			blobs[blob.name] = blob
		if len(blobs)!=4 or "file1.cpp" not in blobs.keys() or "file2.cpp" not in blobs.keys() or "file3.cpp" not in blobs.keys() or "file4.cpp" not in blobs.keys() or len(commit_second_branch[0].tree.trees)!=0:
			msg+="Second-branch has incorrect files and/or directories at extra.cpp removal commit. "
		else:
			result+=3
			msg+="Second-branch has correct files at extra.cpp removal commit. "
			if commit_second_branch[0].message.strip("\n").strip(" ").lower() == "removed extra.cpp":
				msg+="Second-branch commit message at extra.cpp removal is correct. "
				result+=2
			else:
				msg+="Second-branch commit message at extra.cpp removal is incorrect. "

	if checkSecondMerge:
		extra_commits = set(elem.hexsha for elem in commit_master[:5])
		extra_commits -= set(elem.hexsha for elem in commit_first_branch[:1])
		extra_commits -= set(elem.hexsha for elem in commit_second_branch[:2])
		extra_commits -= set(second_merge_commit_hashes)
		merge_commits = [commit for commit in commit_master[:5] if commit.hexsha in extra_commits]
		check_merge = True
		if len(merge_commits)!=2:
			msg+="Total number of merge commits is not 2. "
			check_merge = False

		check = True
		if check_merge:
			merge_commit = merge_commits[1]
			if merge_commit.parents[0].hexsha!=second_merge_commit_hashes[0] or merge_commit.parents[1].hexsha!=commit_first_branch[0].hexsha:
				msg+="First merge is incorrect. "
			else:
				blobs = {}
				for blob in merge_commit.tree.blobs:
					blobs[blob.name] = blob
				if len(blobs)!=4 or "file1.cpp" not in blobs.keys() or "file2.cpp" not in blobs.keys() or "file3.cpp" not in blobs.keys() or "file4.cpp" not in blobs.keys() or len(merge_commit.tree.trees)!=0:
					msg+="First merge has incorrect files and/or directories. "
				else:
					if merge_commit.message.strip("\n").strip(" ").lower() == "merging first-branch into master":
						msg+="First merge commit message is correct. "
						result+=2
					else:
						msg+="First merge commit message is incorrect. "
					curr_blob=blobs["file1.cpp"]
					curr_blob.stream_data(open("file.cpp","wb"))
					ret = os.system("g++ file.cpp")
					if ret!=0:
						msg+="file1.cpp has compilation error in first merge commit. "
					else:
						for i in range(3):
							os.system("timeout 2s ./a.out < testcases/m1_1/in_"+str(i+1)+".txt > output.txt")
							ret = os.system("diff -Bw output.txt testcases/m1_1/out_"+str(i+1)+".txt")
							if ret!=0:
								msg+="file1.cpp failed testcases in first merge commit. "
								check = False
								break
						if check:
							msg+="First merge commit has correct file1.cpp. "
							result+=4
					check = True
					curr_blob=blobs["file2.cpp"]
					curr_blob.stream_data(open("file.cpp","wb"))
					ret = os.system("g++ file.cpp")
					if ret!=0:
						msg+="file2.cpp has compilation error in first merge commit. "
					else:
						for i in range(3):
							os.system("timeout 2s ./a.out < testcases/m1_2/in_"+str(i+1)+".txt > output.txt")
							ret = os.system("diff -Bw output.txt testcases/m1_2/out_"+str(i+1)+".txt")
							if ret!=0:
								msg+="file2.cpp failed testcases in first merge commit. "
								check = False
								break
						if check:
							msg+="First merge commit has correct file2.cpp. "
							result+=4

		check = True
		if check_merge:
			merge_commit = merge_commits[0]
			if merge_commit.parents[0].hexsha!=merge_commits[1].hexsha or merge_commit.parents[1].hexsha!=commit_second_branch[0].hexsha:
				msg+="Second merge is incorrect. "
			else:
				blobs = {}
				for blob in merge_commit.tree.blobs:
					blobs[blob.name] = blob
				if len(blobs)!=5 or "file1.cpp" not in blobs.keys() or "file2.cpp" not in blobs.keys() or "file3.cpp" not in blobs.keys() or "file4_master.cpp" not in blobs.keys() or "file4_second.cpp" not in blobs.keys() or len(merge_commit.tree.trees)!=0:
					msg+="Second merge has incorrect files and/or directories. "
				else:
					if merge_commit.message.strip("\n").strip(" ").lower() == "merging second-branch into master":
						msg+="Second merge commit message is correct. "
						result+=1
					else:
						msg+="Second merge commit message is incorrect. "
					curr_blob=blobs["file3.cpp"]
					curr_blob.stream_data(open("file.cpp","wb"))
					ret = os.system("g++ file.cpp")
					if ret!=0:
						msg+="file3.cpp has compilation error in second merge commit. "
					else:
						for i in range(3):
							os.system("timeout 2s ./a.out < testcases/m2_3/in_"+str(i+1)+".txt > output.txt")
							ret = os.system("diff -Bw output.txt testcases/m2_3/out_"+str(i+1)+".txt")
							if ret!=0:
								msg+="file3.cpp failed testcases in second merge commit. "
								check = False
								break
						if check:
							msg+="Second merge commit has correct file3.cpp. "
							result+=3
					check = True
					curr_blob=blobs["file4_master.cpp"]
					curr_blob.stream_data(open("file.cpp","wb"))
					ret = os.system("g++ file.cpp")
					if ret!=0:
						msg+="file4_master.cpp has compilation error in second merge commit. "
					else:
						for i in range(3):
							os.system("timeout 2s ./a.out < testcases/m2_4_1/in_"+str(i+1)+".txt > output.txt")
							ret = os.system("diff -Bw output.txt testcases/m2_4_1/out_"+str(i+1)+".txt")
							if ret!=0:
								msg+="file4_master.cpp failed testcases in second merge commit. "
								check = False
								break
						if check:
							msg+="Second merge commit has correct file4_master.cpp. "
							result+=3
					check = True
					curr_blob=blobs["file4_second.cpp"]
					curr_blob.stream_data(open("file.cpp","wb"))
					ret = os.system("g++ file.cpp")
					if ret!=0:
						msg+="file4_second.cpp has compilation error in second merge commit. "
					else:
						for i in range(3):
							os.system("timeout 2s ./a.out < testcases/m2_4_2/in_"+str(i+1)+".txt > output.txt")
							ret = os.system("diff -Bw output.txt testcases/m2_4_2/out_"+str(i+1)+".txt")
							if ret!=0:
								msg+="file4_second.cpp failed testcases in second merge commit. "
								check = False
								break
						if check:
							msg+="Second merge commit has correct file4_second.cpp. "
							result+=3

	elif checkFirstMerge:
		extra_commits = set(elem.hexsha for elem in commit_master[:2])
		extra_commits -= set(elem.hexsha for elem in commit_first_branch[:1])
		extra_commits -= set(first_merge_commit_hashes)
		merge_commits = [commit for commit in commit_master[:5] if commit.hexsha in extra_commits]
		check_merge = True
		if len(merge_commits)!=1:
			msg+="Total number of merge commits is not 1. "
			check_merge = False

		check = True
		if check_merge:
			merge_commit = merge_commits[0]
			if merge_commit.parents[0].hexsha!=first_merge_commit_hashes[0] or merge_commit.parents[1].hexsha!=commit_first_branch[0].hexsha:
				msg+="First merge is incorrect. "
			else:
				blobs = {}
				for blob in merge_commit.tree.blobs:
					blobs[blob.name] = blob
				if len(blobs)!=4 or "file1.cpp" not in blobs.keys() or "file2.cpp" not in blobs.keys() or "file3.cpp" not in blobs.keys() or "file4.cpp" not in blobs.keys() or len(merge_commit.tree.trees)!=0:
					msg+="First merge has incorrect files and/or directories. "
				else:
					if merge_commit.message.strip("\n").strip(" ").lower() == "merging first-branch into master":
						msg+="First merge commit message is correct. "
						result+=2
					else:
						msg+="First merge commit message is incorrect. "
					curr_blob=blobs["file1.cpp"]
					curr_blob.stream_data(open("file.cpp","wb"))
					ret = os.system("g++ file.cpp")
					if ret!=0:
						msg+="file1.cpp has compilation error in first merge commit. "
					else:
						for i in range(3):
							os.system("timeout 2s ./a.out < testcases/m1_1/in_"+str(i+1)+".txt > output.txt")
							ret = os.system("diff -Bw output.txt testcases/m1_1/out_"+str(i+1)+".txt")
							if ret!=0:
								msg+="file1.cpp failed testcases in first merge commit. "
								check = False
								break
						if check:
							msg+="First merge commit has correct file1.cpp. "
							result+=4
					check = True
					curr_blob=blobs["file2.cpp"]
					curr_blob.stream_data(open("file.cpp","wb"))
					ret = os.system("g++ file.cpp")
					if ret!=0:
						msg+="file2.cpp has compilation error in first merge commit. "
					else:
						for i in range(3):
							os.system("timeout 2s ./a.out < testcases/m1_2/in_"+str(i+1)+".txt > output.txt")
							ret = os.system("diff -Bw output.txt testcases/m1_2/out_"+str(i+1)+".txt")
							if ret!=0:
								msg+="file2.cpp failed testcases in first merge commit. "
								check = False
								break
						if check:
							msg+="First merge commit has correct file2.cpp. "
							result+=4
		
    
	overall['data'][0]["score"] = result
	overall['data'][0]["status"] = "success"
	overall['data'][0]["message"] = msg
	print(json.dumps(overall, indent=4))
	with open('../evaluate.json', 'w') as f:
		json.dump(overall,f,indent=4)

except Exception as e:
	print("Some error occurred", e)
	exit()

os.system("rm -rf a.out file.cpp output.txt working_directory")