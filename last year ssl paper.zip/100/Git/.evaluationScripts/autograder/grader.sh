#!/bin/bash
pip3 list | grep "GitPython" || pip3 install ./gitdb-4.0.11-py3-none-any.whl ./smmap-5.0.1-py3-none-any.whl ./GitPython-3.1.42-py3-none-any.whl
python3 script.py
