#!/bin/bash

# Reset file contents
rm -rf ../working_directory > /dev/null 2> /dev/null
tar -zxvf working_directory.tgz --directory ../ > /dev/null 2> /dev/null