#!/bin/bash

cd ..
tar -cvzf working_directory.tar.gz working_directory